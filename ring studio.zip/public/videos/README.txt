Please place the 'diamond-360.mp4' video file in this directory.
The video should be a 360-degree rotation of the jewelry item.
